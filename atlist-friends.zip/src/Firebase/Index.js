import FirebaseContext, {withFirebase} from './Context'
import Firebase from './Firebase'
export default Firebase
export { FirebaseContext, withFirebase }